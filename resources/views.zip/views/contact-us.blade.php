<!---thhe banner is here  ---->
  @extends('layouts.index')

@section('content')


<div  align="center">

@include('form')



</div>

@endsection