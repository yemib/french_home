<!---thhe banner is here  ---->
  @extends('layouts.index')

@section('content')

   <?php    
		  
		use Tutorialspoint\contact ;
		  
		  
		  $page = page::first();
		  
		  ?>




   
  <div class="page-title"   style=" background-repeat: no-repeat; background-size: cover"> 
   <div class="container"> 
    <div> 
     <div class="row"> 
      <div class="col-lg-12"> 
       <div class="page-title-heading"> 
        <h1> <a  style="text-shadow: 2px 0 0 green, -2px 0 0 green, 0 2px 0 green, 0 -2px 0 green, 1px 1px green, -1px -1px 0 green, 1px -1px 0 green, -1px 1px 0 green; "  href="#">CONTACT US</a> </h1> 
       </div> 
     
      </div> 
     </div> 
    </div> 
   </div> 
  </div> 
  
   
   <div   style="">
   
    <section class="flat-features-5"> 
    <div class="container"> 
     <div class="row"> 
      
      <div class="col-lg-10 col-md-10 col-sm-10"> 
       <div class="content-features-5"> 
       
       <!---   echo home here   ---->
       
   
       
        <p>  
        
          
            
              
                  </p> 
        
        
        
      
        
       </div> 
      </div> 
      
      
      <div class="col-lg-2 col-md-2 col-sm-2"> 
       <div class="flat-features-5"> 
        
        <h2>Welcome To Odua Cooperative Conglomerate Limited. </h2> 
       </div> 
      </div> 
      
     </div> 
    </div> 
   </section> 
   
   

</div>
 



@endsection