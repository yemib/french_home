  @extends('layouts.index2')

@section('content')

   <?php    
		  
		use Tutorialspoint\page ;
		  
		  
		 // $page = page::find($id);
		  
		  ?>

@section('title')

 aboutr

@endsection

	
<div class="page-header title-area style-1">

	<div class="header-title blog-title" style="background-position: 50% 94px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1 class="page-title">LASCOFED News</h1>				</div>
			</div>
		</div>
	</div>
	
</div>




	<div id="content" class="site-content">
		
		<div class="container">
			<div class="row">

	<div id="primary" class="content-area col-md-8 col-sm-12 col-xs-12">
		<main id="main" class="site-main ">

		
						
				
<article id="post-2786" class="blog-wrapper post-2786 post type-post status-publish format-standard hentry category-latest-news no-thumb">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/communique-of-the-2018-lagos-state-co-operative-federation-lascofed-cooperative-leaders-conference-held-between-thursday-13th-to-sunday-16th-december-201-at-ijebu-ode-conference-rolak-a/"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/communique-of-the-2018-lagos-state-co-operative-federation-lascofed-cooperative-leaders-conference-held-between-thursday-13th-to-sunday-16th-december-201-at-ijebu-ode-conference-rolak-a/">Communique
 Of The 2018 Lagos State Co-Operative Federation (Lascofed) Cooperative 
Leaders’ Conference Held Between Thursday, 13th To Sunday, 16th December
 201 At Ijebu Ode (Conference, Rolak And Hollandas Hotels), Ogun State, 
Nigeria.</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/communique-of-the-2018-lagos-state-co-operative-federation-lascofed-cooperative-leaders-conference-held-between-thursday-13th-to-sunday-16th-december-201-at-ijebu-ode-conference-rolak-a/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-08T00:11:12+00:00">February 8, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/latest-news/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Latest News</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>&nbsp; THEME The theme of the 2018 Lagos State Co-operative 
Federation (LASCOFED) Cooperative Leaders’ Conference is “EXPANDING 
CO-OPERATIVE FRONTIERS” with the sub-theme, “Co-operative Structure and 
Governance as a tool for…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2776" class="blog-wrapper post-2776 post type-post status-publish format-standard hentry category-speeches no-thumb">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/welcome-address-delivered-by-the-president-of-lagos-island-multipurpose-cooperative-union/"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/welcome-address-delivered-by-the-president-of-lagos-island-multipurpose-cooperative-union/">Welcome Address Delivered By The President Of Lagos Island Multipurpose Cooperative Union</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/welcome-address-delivered-by-the-president-of-lagos-island-multipurpose-cooperative-union/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T23:41:53+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/speeches/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Speeches</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>WELCOME ADDRESS DELIVERED BY THE PRESIDENT OF LAGOS ISLAND 
MULTIPURPOSE COOPERATIVE UNION. PROTOCOLS I am indebted to Almighty God,
 the giver of life for giving me this opportunity to welcome…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2774" class="blog-wrapper post-2774 post type-post status-publish format-standard hentry category-latest-news no-thumb">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/address-by-the-lascofed-president-chief-oriyomi-ayeola-at-the-2018-joint-multipurpose-cooperative-union-retreat-held-12th-15th-july-2018/"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/address-by-the-lascofed-president-chief-oriyomi-ayeola-at-the-2018-joint-multipurpose-cooperative-union-retreat-held-12th-15th-july-2018/">Address
 By The Lascofed President, Chief Oriyomi Ayeola, At The 2018 Joint 
Multipurpose Cooperative Union Retreat Held 12th – 15th July, 2018.</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/address-by-the-lascofed-president-chief-oriyomi-ayeola-at-the-2018-joint-multipurpose-cooperative-union-retreat-held-12th-15th-july-2018/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T23:01:43+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/latest-news/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Latest News</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>ADDRESS BY THE LASCOFED PRESIDENT, CHIEF ORIYOMI AYEOLA, AT THE 
2018 JOINT MULTIPURPOSE COOPERATIVE UNION RETREAT HELD 12TH – 15TH JULY,
 2018. PROTOCOLS I am thankful and grateful to Almighty…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2769" class="blog-wrapper post-2769 post type-post status-publish format-standard hentry category-speeches no-thumb">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/welcome-address-delivered-by-the-lascofed-president-chief-oriyomi-ayeola-on-the-occasion-of-the-visitation-of-the-honourable-commissioner-for-the-ministry-of-commerce-industry-and-cooperatives-mrs/"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/welcome-address-delivered-by-the-lascofed-president-chief-oriyomi-ayeola-on-the-occasion-of-the-visitation-of-the-honourable-commissioner-for-the-ministry-of-commerce-industry-and-cooperatives-mrs/">Chief
 Oriyomi Ayeola On The Occasion Of The Visitation Of The Hon 
Commissioner For The Ministry Of Commerce, Industry And Cooperatives, 
Mrs. A. Oladunjoye On 27th June, 2018.</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/welcome-address-delivered-by-the-lascofed-president-chief-oriyomi-ayeola-on-the-occasion-of-the-visitation-of-the-honourable-commissioner-for-the-ministry-of-commerce-industry-and-cooperatives-mrs/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T22:18:24+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/speeches/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Speeches</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>WELCOME ADDRESS DELIVERED BY THE LASCOFED PRESIDENT, CHIEF ORIYOMI 
AYEOLA ON THE OCCASION OF THE VISITATION OF THE HONOURABLE COMMISSIONER 
FOR THE MINISTRY OF COMMERCE, INDUSTRY AND COOPERATIVES, MRS. A.…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2763" class="blog-wrapper post-2763 post type-post status-publish format-standard has-post-thumbnail hentry category-latest-news ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/the-opening-ceremony-of-the-2018-lascofed-cooperative-leaders-conference/"><img src="news_files/lascofed1.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="lascofed1" srcset="http://lascofed.coop/wp-content/uploads/2019/02/lascofed1.jpg 500w, http://lascofed.coop/wp-content/uploads/2019/02/lascofed1-300x123.jpg 300w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="205"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/the-opening-ceremony-of-the-2018-lascofed-cooperative-leaders-conference/">The Opening Ceremony Of The 2018 LASCOFED Cooperative Leaders’ Conference</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/the-opening-ceremony-of-the-2018-lascofed-cooperative-leaders-conference/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T21:47:03+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/latest-news/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Latest News</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>ADDRESS DELIVERED BY THE PRESIDENT OF LASCOFED CHIEF TAJUDEEN 
ORIYOMI AYEOLA AT THE OPENING CEREMONY OF THE 2018 LASCOFED COOPERATIVE 
LEADERS CONFERENCE Protocols On behalf of all members of the…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2759" class="blog-wrapper post-2759 post type-post status-publish format-standard has-post-thumbnail hentry category-latest-news ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/address-delivered-by-the-lascofed-president-high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat-organized-by-ikeja-lagos-island-multipurpose-cooperative-unions-held-16th/"><img src="news_files/Chief-Oriyomi-Ayeola-1.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="Chief Oriyomi Ayeola" srcset="http://lascofed.coop/wp-content/uploads/2019/02/Chief-Oriyomi-Ayeola-1.jpg 500w, http://lascofed.coop/wp-content/uploads/2019/02/Chief-Oriyomi-Ayeola-1-300x123.jpg 300w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="205"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/address-delivered-by-the-lascofed-president-high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat-organized-by-ikeja-lagos-island-multipurpose-cooperative-unions-held-16th/">LASCOFED President At The Cooperative Leaders’ Retreat</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/address-delivered-by-the-lascofed-president-high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat-organized-by-ikeja-lagos-island-multipurpose-cooperative-unions-held-16th/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T21:40:49+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/latest-news/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Latest News</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>&nbsp;ADDRESS DELIVERED BY THE LASCOFED PRESIDENT, HIGH CHIEF 
ORIYOMI AYEOLA AT THE COOPERATIVE LEADERS’ RETREAT ORGANIZED BY IKEJA 
&amp; LAGOS ISLAND MULTIPURPOSE COOPERATIVE UNIONS HELD 16TH – 19TH 
AUGUST, 2018.…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2754" class="blog-wrapper post-2754 post type-post status-publish format-standard has-post-thumbnail hentry category-speeches ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat/"><img src="news_files/Chief-Oriyomi-Ayeola-1.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="Chief Oriyomi Ayeola" srcset="http://lascofed.coop/wp-content/uploads/2019/02/Chief-Oriyomi-Ayeola-1.jpg 500w, http://lascofed.coop/wp-content/uploads/2019/02/Chief-Oriyomi-Ayeola-1-300x123.jpg 300w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="205"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat/">High Chief Oriyomi Ayeola At The Cooperative Leaders’ Retreat</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/high-chief-oriyomi-ayeola-at-the-cooperative-leaders-retreat/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T21:00:37+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/speeches/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Speeches</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>ADDRESS DELIVERED BY THE LASCOFED PRESIDENT, HIGH CHIEF ORIYOMI 
AYEOLA AT THE COOPERATIVE LEADERS’ RETREAT ORGANIZED BY IKEJA &amp; 
LAGOS ISLAND MULTIPURPOSE COOPERATIVE UNIONS HELD 16TH – 19TH AUGUST, 
2018.…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2749" class="blog-wrapper post-2749 post type-post status-publish format-standard has-post-thumbnail hentry category-speeches ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/address-delivered-by-lascofed-president-chief-oriyomi-ayeola/"><img src="news_files/Oriyomi-Ayeola.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="Oriyomi Ayeola" srcset="http://lascofed.coop/wp-content/uploads/2019/02/Oriyomi-Ayeola.jpg 500w, http://lascofed.coop/wp-content/uploads/2019/02/Oriyomi-Ayeola-300x123.jpg 300w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="205"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/address-delivered-by-lascofed-president-chief-oriyomi-ayeola/">Address Delivered By Lascofed President, Chief Oriyomi Ayeola</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/address-delivered-by-lascofed-president-chief-oriyomi-ayeola/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T20:42:38+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/speeches/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Speeches</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>Address Delivered By Lascofed President, Chief Oriyomi Ayeola, At 
The 2018 International Cooperative Day Celebrations. PROTOCOLS First and
 Foremost, I thank God Almighty for the privilege of 2018 International 
Cooperative…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-2740" class="blog-wrapper post-2740 post type-post status-publish format-standard has-post-thumbnail hentry category-speeches ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/the-keynote-address-delivered-by-hon-commissioner-ministry-of-commerce-industry-cooperatives-mrs-olayinka-oladunjoye-lascofed-cooperative-leaders-conference/"><img src="news_files/Mrs-Oladunjoye-Olayinka.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="Mrs Oladunjoye Olayinka" srcset="http://lascofed.coop/wp-content/uploads/2019/02/Mrs-Oladunjoye-Olayinka.jpg 424w, http://lascofed.coop/wp-content/uploads/2019/02/Mrs-Oladunjoye-Olayinka-300x146.jpg 300w" sizes="(max-width: 424px) 100vw, 424px" width="424" height="206"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/the-keynote-address-delivered-by-hon-commissioner-ministry-of-commerce-industry-cooperatives-mrs-olayinka-oladunjoye-lascofed-cooperative-leaders-conference/">The Keynote Address Delivered Mrs. Olayinka Oladunjoye</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/the-keynote-address-delivered-by-hon-commissioner-ministry-of-commerce-industry-cooperatives-mrs-olayinka-oladunjoye-lascofed-cooperative-leaders-conference/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2019-02-07T19:00:13+00:00">February 7, 2019</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/speeches/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Speeches</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>Being The Keynote Address Delivered By Honourable Commissioner, 
Ministry Of Commerce, Industry And Cooperatives Mrs. Olayinka 
Oladunjoye, Lascofed Cooperative Leaders Conference Held At Rolak Hotel,
 Ijebu Ode, Ogun State On…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				
<article id="post-714" class="blog-wrapper post-714 post type-post status-publish format-standard has-post-thumbnail hentry category-latest-news ">
	<div class="entry-thumbnail">
		<a href="http://lascofed.coop/communication-is-cheap-on-lascofed-connect-oriyomi-ayeola/"><img src="news_files/lascofed-connect.jpg" class="attachment-factoryhub-blog-thumb size-factoryhub-blog-thumb wp-post-image" alt="lascofed-connect" srcset="http://lascofed.coop/wp-content/uploads/2017/11/lascofed-connect.jpg 1023w, http://lascofed.coop/wp-content/uploads/2017/11/lascofed-connect-300x165.jpg 300w, http://lascofed.coop/wp-content/uploads/2017/11/lascofed-connect-768x423.jpg 768w" sizes="(max-width: 760px) 100vw, 760px" width="760" height="418"><i class="fa fa-link" aria-hidden="true"></i></a>
	</div>
	<header class="entry-header">
					<h2 class="entry-title"><a href="http://lascofed.coop/communication-is-cheap-on-lascofed-connect-oriyomi-ayeola/">Communication Is Cheap On Lascofed Connect – Oriyomi Ayeola</a></h2>
		
		<div class="entry-meta">
			<span class="meta posted-on"><a href="http://lascofed.coop/communication-is-cheap-on-lascofed-connect-oriyomi-ayeola/" rel="bookmark"><i class="fa fa-clock-o" aria-hidden="true"></i><time class="entry-date published updated" datetime="2017-11-17T15:51:59+00:00">November 17, 2017</time></a></span>
							<span class="meta cat-link">
				<a href="http://lascofed.coop/category/latest-news/" class="category-link"><i class="fa fa-tags" aria-hidden="true"></i>Latest News</a>			</span>
				
		</div><!-- .entry-meta -->

		
	</header><!-- .entry-header -->

	<div class="entry-content">
		<p>The President of Lagos State Cooperative Federation, Mr. Oriyomi 
Ayeola, has revealed that LASCOFED CONNECT would make communication 
easier and cheaper for cooperators and their families. The special 
closed-user-group (CUG)…</p>

			</div><!-- .entry-content -->

	<footer class="entry-footer clearfix">
				<div class="post-author-avatar">
			<img alt="" src="news_files/76b43073128e6f7a0414c9267846b827.jpg" srcset="http://1.gravatar.com/avatar/76b43073128e6f7a0414c9267846b827?s=100&amp;d=mm&amp;r=g 2x" class="avatar avatar-50 photo" width="50" height="50">		</div>
		<div class="post-author-info">
			<h3 class="author-name">lascofed</h3>
		</div>
			</footer>

</article><!-- #post-## -->

			
				<nav class="navigation paging-navigation numeric-navigation">
		<span class="page-numbers current">1</span>
<a class="page-numbers" href="http://lascofed.coop/blog/page/2/">2</a>
<a class="page-numbers" href="http://lascofed.coop/blog/page/3/">3</a>
<span class="page-numbers dots">…</span>
<a class="page-numbers" href="http://lascofed.coop/blog/page/5/">5</a>
<a class="next page-numbers" href="http://lascofed.coop/blog/page/2/"><i class="fa fa-angle-right" aria-hidden="true"></i></a>	</nav>

		
		</main><!-- #main -->
	</div><!-- #primary -->

<aside id="primary-sidebar" class="widgets-area primary-sidebar blog-sidebar col-xs-12 col-sm-12 col-md-4">


	<div class="factoryhub-widget">
		<div id="categories-2" class="widget widget_categories"><h4 class="widget-title">Categories</h4>		<ul>
	<li class="cat-item cat-item-5"><a href="http://lascofed.coop/category/cooplight-news/">Cooplight News</a>
</li>
	<li class="cat-item cat-item-1"><a href="http://lascofed.coop/category/latest-news/">Latest News</a>
</li>
	<li class="cat-item cat-item-4"><a href="http://lascofed.coop/category/speeches/">Speeches</a>
</li>
		</ul>
</div>	</div>
</aside>
		
		<!-- #secondary -->
			</div> <!-- .row -->
		</div> <!-- .container -->
	</div><!-- #content -->

	
	@endsection
