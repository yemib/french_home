<h1>Loading.....</h1>
<script>
window.location="https://web.itwtech.online/register.php";
</script>