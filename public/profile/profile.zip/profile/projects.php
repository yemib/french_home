<?php 
		  
		  image_move("Cryptocurrency Exchage System"  ,   "https://exmaster.online" , "Cryptocurrency Exchage Website" ) ;

		  //image_move("Timelogger"  ,   "https://timelogger.exmaster.online" , "Employee Attendance Tracking System" ) ;
		  image_move("Movers and Cleaners"  ,   "https://apmovers.exmaster.online" , "Service Rendering System" ) ;
          image_move("Law Firm"  ,   "https://brainmax.exmaster.online" , "Service" ) ;
          image_move("Chabroz"  ,   "https://chaboz.exmaster.online" , "E-commerce" ) ;

          image_move("E-commerce"  ,   "https://moi.exmaster.online" , "E-commerce" ) ;
		  image_move("Food Vendor"  ,   "https://amaz.exmaster.online" , "E-commerce" ) ;
		 
		  
		  image_move("E-commerce"  ,   "https://silkstone.exmaster.online" , "E-commerce" ) ;

          image_move("School Website"  ,   "https://elpaal.exmaster.online" , "School Website" ) ;

		  image_move("Higher Institution Website"  ,   "https://frenchvillage.edu.ng" , "FRENCH VILLAGE" ) ;
		  
		
		    image_move("TOCHEX WATER"  ,   "https://tochexpremiumwater.com/" , "TOCHEX PREMIUM WATER" ) ;

		  
		  image_move("Organisation  Website"  ,   "https://wholeplanetinitiative.org" , "MHSOSA" ) ;
		 
		  image_move("NGO Website"  ,   "https://olotuglobalfoundation.org/" , "OLOTU GLOBAL TOUCH FOUNDATION" ) ;
		 
      //image_move("BLOG"  ,   "https://blog.exmaster.online" , "Tutorial Blog" ) ;


?>