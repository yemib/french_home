<?php

namespace Tutorialspoint;

use Illuminate\Database\Eloquent\Model;

class service extends Model
{
    //
}
