<?php

namespace Tutorialspoint;

use Illuminate\Database\Eloquent\Model;

class logos extends Model
{
    //
}
