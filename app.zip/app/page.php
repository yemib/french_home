<?php

namespace Tutorialspoint;

use Illuminate\Database\Eloquent\Model;

class page extends Model
{
    //
}
