<?php

namespace Tutorialspoint;

use Illuminate\Database\Eloquent\Model;

class management extends Model
{
    //
}
