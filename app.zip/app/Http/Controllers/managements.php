<?php

namespace Tutorialspoint\Http\Controllers;

use Illuminate\Http\Request;
use Tutorialspoint\management;

class managements extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
		 public function __construct()
    {
        $this->middleware('article');

       
    }
	
	
    public function index()
    {
        //
		return(   view('admin_folder/management') );
		
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		
		return view('admin_folder/add_management');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
		
		$teacher  = new management();
		
		$teacher->name  = $request->name;
		
		$teacher->position  = $request->position;
		
		
		$teacher->phone  =   ($request->phone  != '' ) ?  $request->phone   : ' ' ;
		
		$teacher->category  =( $request->category != '' ) ?  $request->category  :  ' ' ;
		
		
		$teacher->description  = $request->description;
		
		
		
		$teacher->publish  =(isset($request->publish) ) ?  $request->publish  :  'no' ;
		
		
		
		if($request->image  != ''){  
			
			$image = $request->file('picture');
			$getsize =  $image->getSize();
	$original_name =$image->getClientOriginalName();
	$new_name = rand() . '.' . $image->getClientOriginalExtension();
	$real_path  =   $image->getRealPath();
	$image->move(public_path('picture_servic'), $new_name);
			
			$teacher->image  =	'/picture_servic/'.$new_name;
		
		}else{
			
		$teacher->image  =	'  ' ;
		}
		
		
		
		
		
	
		
		
		
		
		$teacher->save();
		
		
		return  redirect('/managements');
		
		
		
		
		
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		
		     //
		$all = array('edit'=> 'edit'  , 'id'=> $id);
		
			return view('admin_folder/add_management')->with($all);
		
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		
		$teacher  = management::find($id);
		
		$teacher->name  = $request->name;
		$teacher->position  = $request->position;
		
			
		$teacher->phone  =   ($request->phone  != '' ) ?  $request->phone   : ' ' ;
		
		$teacher->category  =( $request->category != '' ) ?  $request->category  :  ' ' ;
		
		
		$teacher->description  = $request->description;
		
		
		$teacher->publish  =(isset($request->publish) ) ?  $request->publish  :  'no' ;
		
				if($request->image  != ''){  
			
			$image = $request->file('picture');
			$getsize =  $image->getSize();
	$original_name =$image->getClientOriginalName();
	$new_name = rand() . '.' . $image->getClientOriginalExtension();
	$real_path  =   $image->getRealPath();
	$image->move(public_path('picture_servic'), $new_name);
			
			$teacher->image  =	'/picture_servic/'.$new_name;
		
		}else{
			
	
		}
		
		
		
		$teacher->save();
		
		
		return  redirect('/managements');
		
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		
			$teacher  = management::find($id);
		$teacher->delete();
		
		return   redirect('/managements');
		
    }
}
