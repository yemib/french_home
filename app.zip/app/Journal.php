<?php

namespace Tutorialspoint;

use Illuminate\Database\Eloquent\Model;

class Journal extends Model
{
    //
    protected $guarded = [];
}
